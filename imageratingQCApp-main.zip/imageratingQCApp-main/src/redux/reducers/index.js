import { combineReducers } from "redux";
import images from './images';
import phase from './phase';

export default combineReducers({
	images,
	phase
});
